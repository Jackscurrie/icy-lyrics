# Android extraction pixel parity

Exact RGBA pixels; no masks, resizing, tolerances, or accepted differences.

| Scenario | Result | Changed pixels | Dimensions |
|---|---|---:|---|
| onboarding | identical | 0 | [1080, 2400] |
| empty | identical | 0 | [1080, 2400] |
| portrait | identical | 0 | [1080, 2400] |
| portrait-long | identical | 0 | [1080, 2400] |
| portrait-failed | identical | 0 | [1080, 2400] |
| background-static | identical | 0 | [1080, 2400] |
| background-disabled | identical | 0 | [1080, 2400] |
| reduced-motion | identical | 0 | [1080, 2400] |
| settings | identical | 0 | [1080, 2400] |
| library | identical | 0 | [1080, 2400] |
| library-empty | identical | 0 | [1080, 2400] |
| legal | identical | 0 | [1080, 2400] |
| diagnostics | identical | 0 | [1080, 2400] |
| landscape-artwork | identical | 0 | [2400, 1080] |
| landscape-titles | identical | 0 | [2400, 1080] |
| landscape-mixed | identical | 0 | [2400, 1080] |
| landscape-lyrics | identical | 0 | [2400, 1080] |
| landscape-mixed-right | identical | 0 | [2400, 1080] |
| multilingual | identical | 0 | [2400, 1080] |
| syllables | identical | 0 | [2400, 1080] |

Baseline production-source hashes unchanged: True

These captures verify Android before/after extraction only. iOS native linking, screenshots, animation trajectories, traditional-Chinese locale fallback, complex emoji shaping, and physical-device output require separate verification.
